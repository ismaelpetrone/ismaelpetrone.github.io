from classes.Client import Client

def main():
    client_name = str(input('Insert your name: '))
    client = Client(client_name.capitalize())
    client.start()

main()