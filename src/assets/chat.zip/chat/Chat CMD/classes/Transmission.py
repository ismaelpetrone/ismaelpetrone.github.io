import json
import winsound

class TransmissionSender():
	def __init__(self, dataType, data, owner):
		self.dataType = dataType
		self.data = data
		self.owner = owner
		
	def getBytesUTF8(self):
		return bytes(json.dumps(self, default=lambda o: o.__dict__, sort_keys=True, indent=3), 'UTF-8')

class TransmissionReceiver():
	def __init__(self, responseBytes):
		decodedBytes = responseBytes.decode("utf-8")
		data = json.loads(decodedBytes)
		self.dataType = data["dataType"]
		self.data = data["data"]
		self.owner = data["owner"]

class TransmissionInterpreter():
    def __init__(self, tr):
        if (tr.dataType == 'joined'):
            winsound.PlaySound('sounds/login.wav', winsound.SND_ASYNC)
        elif (tr.dataType == 'closed'):
            winsound.PlaySound('sounds/logout.wav', winsound.SND_ASYNC)
        elif(tr.dataType == 'message'):
            print(tr.owner + ': ' + tr.data)
            if (enableNotification):
                winsound.PlaySound('sounds/notificacion.wav', winsound.SND_ASYNC)
        elif(tr.dataType == 'alert'):
            winsound.Beep(2000, 1000)