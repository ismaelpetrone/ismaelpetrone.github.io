import socket
import sys
import os
import threading
import random
import atexit
import time
from classes.Network import Network
from classes.Transmission import TransmissionSender, TransmissionReceiver

class Server():
    def __init__(self, name):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.network = Network()
        self.ip_server = self.network.getIP()
        self.port = 64552
        self.server_address = (self.ip_server, self.port)
        self.clients = {}
        self.name = name

    def sendAllDisconnectAlert(self, message):
        for clientKey in self.clients:
            connection = self.clients.get(clientKey)
            if connection:
                connection.sendall(message)

    def sendAll(self, msg, actualClientKey):
        message = msg.encode('utf-8')
        time.sleep(1)
        for clientKey in self.clients:
            if clientKey != actualClientKey:
                connection = self.clients.get(clientKey)
                if connection:
                    connection.sendall(message)

    def whileRead(self, clientKey):
        try:
            while True:
                connection = self.clients.get(clientKey)
                if connection:
                    data = connection.recv(128)
                    if data:
                        msg = str(data.decode("utf-8"))
                        thread3 = threading.Thread(target=self.sendAll, args=(msg,clientKey))
                        thread3.start()
                    else:
                        raise Exception()
        except:
            if self.clients.get(clientKey):
                self.clients.get(clientKey).close()
                del self.clients[clientKey]
                self.sendAllDisconnectAlert(TransmissionSender('closed', '', 'from Admin').getBytesUTF8())

    def generateRandomString(self):
        return 'id' + str(random.randint(1, 10000))

    def getAvaiableClientKey(self, possibleKey):
        if (possibleKey in self.clients):
            self.getAvaiableClientKey(generateRandom())
        return possibleKey

    def start(self):
        self.sock.bind(self.server_address)
        os.system('cls')
        print('LISTENING SERVER: ' + self.ip_server + ':' + str(self.port) + ' (' + str(self.name) + ')')
        self.sock.listen(1)

        while True:
            # WAITING CONNECTION
            connection, client_address = self.sock.accept()
            randomKey = self.generateRandomString()
            clientKey = self.getAvaiableClientKey(randomKey)
            self.clients[randomKey] = connection
            thread2 = threading.Thread(target=self.whileRead, args=(clientKey,))
            thread2.start()