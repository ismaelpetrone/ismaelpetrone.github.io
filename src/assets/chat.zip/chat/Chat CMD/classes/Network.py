import socket
import sys

class Network ():
    def __init__(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        IP = 0
        try:
            s.connect(('10.255.255.255', 1))
            IP = s.getsockname()[0]
        except:
            raise NotImplementedError("Catch exception", type(self))            
        self.ip = IP
        self.network = ''

    def getIP(self):
        return str(self.ip)

    def getNetwork(self):
        net = self.ip.split('.')
        self.network = str(net[0]) + '.' + str(net[1]) + '.' + str(net[2]) + '.255'
        return self.network

    def isClaseC(self):
        min = [192, 0, 1, 1]
        max = [223, 255, 254, 254]
        ipSplitted = str(self.ip).split('.')
        if (
        (int(ipSplitted[0]) >= min[0] and int(ipSplitted[0]) <= max[0]) and
        (int(ipSplitted[1]) >= min[1] and int(ipSplitted[1]) <= max[1]) and
        (int(ipSplitted[2]) >= min[2] and int(ipSplitted[2]) <= max[2]) and
        (int(ipSplitted[3]) >= min[3] and int(ipSplitted[3]) <= max[3])
        ):
            return True
        return False

    def getClase(self):
        claseC = { 'min': 192, 'max': 223 }
        claseB = { 'min': 128, 'max': 191 }
        ipSplitted = str(self.ip).split('.')
        byte = int(ipSplitted[0])
        if (byte >= claseC.get('min') and byte <= claseC.get('max')):
            return 'c'
        elif (byte >= claseB.get('min') and byte <= claseB.get('max')):
            return 'b'
        return None