import socket
import os
import sys
import threading
from classes.Transmission import TransmissionSender, TransmissionReceiver, TransmissionInterpreter
from classes.Network import Network
import datetime
import winsound
import time

class Client():
    def __init__(self, name):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.port = 64552
        self.enableNotification = True
        self.network = Network()
        self.ip_address = self.network.getIP()
        self.clase = self.network.getClase()
        self.servers = {}
        self.name = name

    def sending(self, sock, transmissionSender):
        if (transmissionSender):        
            self, sock.sendall(transmissionSender.getBytesUTF8())

    def reading(self, sock):
        amount_received = 0
        amount_expected = 1024
        while amount_received < amount_expected:
            try:
                data = sock.recv(128)
                if data:
                    amount_received += len(data)
                    result = TransmissionReceiver(data)
                    TransmissionInterpreter(result)
                else:
                    break
            except:
                error = True

    def recursiveSockHandle(self, sock, port):	
        ip = input('Insert server address: ')
        server_address = (ip, port)
        try:
            sock.connect(server_address)
            return ip
        except:
            recursiveSockHandle(sock, port)

    def isPortOpened(self, ip, port, servers):    
        try:
            sockForTest = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            server_address_test = (ip, port)
            sockForTest.connect(server_address_test)
            servers[str(len(servers) + 1)] = ip
            sockForTest.close()
            sockForTest = None
        except:
            sockForTest.close()
            sockForTest = None

    def getListOfServersClassC(self, original_ip_address, port, servers):
        splitted_net = original_ip_address.split('.')
        for i in range(1, 254, 1):        
            actual_ip = splitted_net[0] + '.' + splitted_net[1] + '.' + splitted_net[2] + '.' + str(i)        
            thread4 = threading.Thread(target=self.isPortOpened, args=(actual_ip,port,servers))
            thread4.start()
        
    def getListOfServersClassB(self, original_ip_address, port, servers):
        splitted_net = original_ip_address.split('.')
        for i in range(1, 254, 1): # se supone que va otro bucle porque tiene 2 bytes de hosts, pero peta
            actual_ip = splitted_net[0] + '.' + splitted_net[1] + '.' + splitted_net[2] + '.' + str(i)        
            thread5 = threading.Thread(target=self.isPortOpened, args=(actual_ip,port,servers))
            thread5.start()
        
    def recursiveServerHandle(self, servers): 
        numero = str(input('Select server number: '))
        if (numero in servers):               
            return servers.get(numero) 
        else:
            return recursiveServerHandle(servers)

    def connectSelectedIp(self, sock, ip, port):
        try:
            server_address = (ip, port)        
            sock.connect(server_address)
            return ip
        except:
            time.sleep(1)
            print('Retrying...')
            connectSelectedIp(sock, ip, port)

    def printServers(self):
        if (self.clase == 'c'):
            print('Scanning...')
            self.getListOfServersClassC(self.ip_address, self.port, self.servers)
        elif (self.clase == 'b'):
            print('Scanning...')
            self.getListOfServersClassB(self.ip_address, self.port, self.servers)

    def askForIp(self):
        ip = None
        if len(self.servers)<1:
            print('Server not found')
            ip = self.recursiveSockHandle(self.sock, self.port)
        else:
            for key, value in self.servers.items():
                print(key + ') ' + value)
            ip_selected = self.recursiveServerHandle(self.servers)
            ip = self.connectSelectedIp(self.sock, ip_selected, self.port)
        return ip

    def start(self):
        self.printServers()
        time.sleep(1)
        ip = self.askForIp()
        print('CONNECTING TO: ' + str(ip) + ':' + str(self.port))
        os.system('cls')
        write = TransmissionSender('joined', '', self.name)
        print('You just joined the chat')

        try:
            while True:
                thread2 = threading.Thread(target=self.sending, args=(self.sock, write))
                thread2.start()
                thread3 = threading.Thread(target=self.reading, args=(self.sock,))
                thread3.start()
                typingText = input()
                if (typingText == 'alert()' and self.name == 'Admin'):
                    write = TransmissionSender('alert', '', self.name)
                elif (typingText == 'enableNotification()'):
                    self.enableNotification = True
                elif (typingText == 'disableNotification()'):
                    self.enableNotification = False
                elif (len(typingText) > 0):
                    write = TransmissionSender('message', typingText, self.name)            
        finally:
            self.sock.close()