from classes.Server import Server

def main():
    server_name = str(input('Insert your server\'s name: '))
    s = Server(server_name)
    s.start()

main()