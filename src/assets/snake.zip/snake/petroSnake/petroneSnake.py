# import the pygame module, so you can use it
import pygame
import msvcrt
import time
import random
from classes.snake import Snake, Part
from classes.stage import Stage
from classes.fruit import Fruit

def sleep(times):
    time.sleep(times)

def waitKeyPress():
    msvcrt.getch()

# transparent (remove pink border)
def correctImage(image):
    return image.set_colorkey((255, 0, 255))

# create a surface on screen
def setSurface(width, height):
    return pygame.display.set_mode((width, height))

# load image
def loadImage(imagepath):
    return pygame.image.load(imagepath)

# copy the pixels of the image surface to the screen surface
def copySurface(image, screen, x, y):
    screen.blit(image, (x, y))
    pygame.display.flip()

# load and set the logo
def setLogo():
    logo = loadImage('media/logo.jpg')
    pygame.display.set_icon(logo)
    pygame.display.set_caption('snake')

def loadStartScreen(screen, counter = 1):
    if (counter == 1):
        image = pygame.image.load('media/background.png')
    copySurface(image, screen, 0, 0)
    writeText('PRESS ANY KEY TO CONTINUE', screen, 2, 256 / 2 , 'comicsansms', 16)
    pygame.display.flip()
    return counter

def loadBackground(screenpath, screen):
    image = pygame.image.load(screenpath)
    copySurface(image, screen, 0, 0)

def loadPlayer(screen, x, y):
    snake = Snake('snake', 0, 0, 0, [Part(x, y, 8, 8)], None)
    return snake

def drawFruit(fruit, screen):
    drawRectangle(screen, (255, 160, 122), fruit.getRect())


def checkLimitsOut(snake):
    for i in range (len(snake.parts)):
        snaky = snake.parts[i]
        if (snaky.x < 0 or snaky.x > 248):
            return True
        if (snaky.y < 32 or snaky.y > 250):
            return True
    return False

def findSelectedStage(stages):
    for i in range(len(stages)):
        if (stages[i].status == 1):
            return [stages[i], i]
    return [stages[0], 0]

def drawRectangle(screen, color, rect):
    pygame.draw.rect(screen, color, rect)

def autoMoveSnake(snake, direction, screen):
    for i in range (len(snake.parts) - 1, -1, -1):
        if i == 0:
            if direction == 2:
                snake.parts[0].x -= 8
            elif direction == 1:
                snake.parts[0].x += 8
            elif direction == 3:
                snake.parts[0].y -= 8
            elif direction == 4:
                snake.parts[0].y += 8
            drawRectangle(screen, (255, 255, 255), snake.parts[0].getRect())
        else:
            snake.parts[i].x = snake.parts[i - 1].x
            snake.parts[i].y = snake.parts[i - 1].y
            drawRectangle(screen, (0, 0, 0), snake.parts[i].getRect())

def moveSnake(event, direction):
    if (event.key == pygame.K_LEFT or event.key == pygame.K_a):
        direction = 2
    elif (event.key == pygame.K_RIGHT or event.key == pygame.K_d):
        direction = 1
    elif (event.key == pygame.K_UP or event.key == pygame.K_w):
        direction = 3
    elif (event.key == pygame.K_DOWN or event.key == pygame.K_s):
        direction = 4
    return direction

def gameOver(screen, timePlayed, score):
    # GameOver
    image = loadImage('media/background.png')
    copySurface(image, screen, 0, 0)
    writeText('GAME OVER', screen, 256/2-60, 256/2, 'comicsansms', 20)
    writeText('TIME:' + str(timePlayed) + "''", screen, 256/2-45, 256/2+30, 'comicsansms', 20)
    writeText('SCORE:' + str(score) + "", screen, 256/2-45, 256 / 2 + 60, 'comicsansms', 20)
    pygame.display.flip()
    sleep(3)

def writeText(texts, screen, x, y, font, size):
    font = pygame.font.SysFont(font, size)
    text = font.render(texts, True, (255, 255, 255))
    screen.blit(text, pygame.Vector2(x, y))

def intersect(rect, rect1):
    if rect1.colliderect(rect):
        return True
    return False

def detectCollision(snaky, fruits):
    fruitRect = fruits.rect.getRect()
    snakeRect = snaky.parts[0].getRect()
    return intersect(fruitRect, snakeRect)

def checkOwnCollision(snake):
    head = snake.parts[0].getRect()
    for i in range(1, len(snake.parts), 1):
        bodyPart = snake.parts[i].getRect()
        if (intersect(bodyPart, head)):
            return True
    return False

def appendPartToSnake(snake, direction):
    lastPart = snake.parts[len(snake.parts) - 1]
    if direction == 2:
        x = lastPart.x + 8
        y = lastPart.y
    if direction == 1:
        x = lastPart.x - 8
        y = lastPart.y
    if direction == 3:
        y = lastPart.y + 8
        x = lastPart.x
    if direction == 4:
        y = lastPart.y - 8
        x = lastPart.x
    snake.parts.append(Part(x, y, 8, 8))

#define a main function
def main():
    # initialize the pygame module
    pygame.init()

    scores = 0

    # 1 right 2 left 3 top 4 bottom
    direction = 1

    screen = setSurface(256, 282)

    pygame.display.set_caption('Slither')

    # define a variable to control the main loop
    running = True

    snake = loadPlayer(screen, 70, 80)

    stages = [
        Stage(1, 1, loadImage('media/stages/2.png'), 6, 35)
    ]

    timePlay = 0

    gameTime = 0

    timeStart = False

    timeNow = 0

    pygame.display.set_mode

    setLogo()

    loadStartScreen(screen)

    clock = pygame.time.Clock()

    # pygame.event.set_grab(True)
    startGame = False
    fruitx = random.randint(8, 245)
    fruity = random.randint(34, 248)
    val = random.randint(1, 2)
    fruit = Fruit(Part(fruitx, fruity, 4, 4), val)

    fps = 5

    # main loop
    while running:
        # event handling, gets all event from the eventqueue
        for event in pygame.event.get():
            # only do something if the event is of type QUIT
            if event.type == pygame.QUIT:
                # change the value to False, to exit the main loop
                return False

            if event.type == pygame.KEYDOWN:
                direction = moveSnake(event, direction)

            if (event.type == pygame.KEYDOWN):
                startGame = True

        if startGame:
            # change in the future
            stageData = findSelectedStage(stages)
            stage = stageData[0]
            if (checkLimitsOut(snake) == True or checkOwnCollision(snake) == True or int(round(stage.time - timePlay)) <= 0):
                gameOver(screen, gameTime, scores)
                timePlay = 0
                return True

            if (stage.points <= scores) :
                #update scores
                stage.time += stage.time / 3
                stage.points *= 1.8
                timePlay *= 0.75
                fps += (fps / 75)

            #screen.fill((0, 0, 0))
            if timeStart == False:
                timeNow = int(round(time.time()))
                timeStart = True

            timePlay = int(round(time.time())) - timeNow
            gameTime = int(round(time.time())) - timeNow

            # copiamos el mapa
            copySurface(stage.terrainImage, screen, 0, 0)

            # escribismo datos de puntuacion
            writeText('SCORE:' + str(scores) + '/' + str(int(round(stage.points))), screen, 10, 2, 'comicsansms', 12)
            writeText('TIME:' + str(gameTime), screen, 195, 2, 'comicsansms', 12)
            writeText(str(int(round(stage.time - timePlay))), screen, 120, 2, 'comicsansms', 12)

            # movemos el gusano y lo dibujamos
            autoMoveSnake(snake, direction, screen)
            # create fruit
            if (fruit.eaten == True):
                fruitx = random.randint(8, 245)
                fruity = random.randint(34, 248)
                val = random.randint(1, 2)
                fruit = Fruit(Part(fruitx, fruity, 4, 4), val)
            drawFruit(fruit, screen)
            if detectCollision(snake, fruit) == True:
                scores += fruit.value
                appendPartToSnake(snake, direction)
                fruit.eaten = True

        pygame.display.update()
        clock.tick(fps)

# run the main function only if this module is executed as the main script
# (if you import this as a module then nothing is executed)
if __name__ == '__main__':
    # call the main function
    finish = True
    while finish:
        finish = main()