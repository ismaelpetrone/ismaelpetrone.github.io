class Stage:
  def __init__(self, id, status, terrainImage, points, time):
    self.id = id
    self.status = status
    self.drawed = False
    self.terrainImage = terrainImage
    self.points = points
    self.time = time