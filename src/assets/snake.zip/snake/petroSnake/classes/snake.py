import pygame

class Part:
    def __init__(self, x, y, width = 0, height = 0):
        self.x = x
        self.y = y
        self.width = width
        self.height = height

    def getRect(self):
        return pygame.Rect(self.x, self.y, self.width, self.height)

class Player:
  def __init__(self, name, x, y, z, playerImage):
    self.name = name
    self.x = x
    self.y = y
    self.z = z
    self.playerImage = playerImage

class Snake(Player):
    def __init__(self, name, x, y, z, parts, playerImage):
        self.name = name
        self.x = x
        self.y = y
        self.z = z
        self.parts = parts

    def getPlayerImage(self):
        return self.playerImage