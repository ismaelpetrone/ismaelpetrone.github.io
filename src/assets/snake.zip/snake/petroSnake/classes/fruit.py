class Fruit:
  def __init__(self, part, value):
      self.rect = part
      self.value = value
      self.eaten = False

  def getRect(self):
      return self.rect.getRect()